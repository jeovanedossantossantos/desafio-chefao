export const Authorization = "S$@GYKrdqnvp"
// export const API = "https://api-cafe-desafio.herokuapp.com"
export const API = "http://localhost:3333"